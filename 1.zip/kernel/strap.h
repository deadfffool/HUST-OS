#ifndef _STRAP_H_
#define _STRAP_H_

void smode_trap_handler(void);

#endif
